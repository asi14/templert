import java.util.*; //import. Cannot use certain functions without importing them.
//the above library is an util library


public class HelloWorld //case sensitive-- helloworld would not work
{
  public static void main(String[] arg)
  {
 	Scanner sc = new Scanner(system.in);
    int a = sc.nextInt();
    String a = sc.nextLine();
   	double b = sc.nextDouble();
    //user function
    //sc = variable
    //just type it in and it will work
    //but object oriented programming is like a more advanced version of using java
    int looping = 1;
    String a = "Hey Bob!1234";
    String b = "123";
    b = b+12;
    sc.
    int c = 12; //int 1,2,-1,-5....
    int d = c * 9;
    //gives out 12312
    double e = 6.9;
    double f = e * 2;
    int [] integers = {19, 18, 18, 18, 17};
   	int [] integers1 = new int[3];
    //[] shows array
    //integers [index]
    //integers[0] = 19
    //integers[1] = 20
    // ...
    // note: nearly all arrays in CS start at 0
    float g = 2.2f;
    System.out.println(f);
    System.out.println("Hello");
    System.out.println(a);
    System.out.println(d);
    //== is it equal to?
    // != is it not equal to?
    //if function checks each if condition until it executes the last else statement.
    
    if (c==12)
    {
    	System.out.println(10); 
    }
    else if (c == 11)
    {
     	System.out.println("c is 11"); 
    }
    else
    {
     	System.out.println("error"); 
    }
    for(int i = 1; i<4; i++)
    {
      System.out.println(i);
      System.out.println(integers[i]);
    }
    while(looping<=10)
    {
      System.out.println(looping);
      looping++; //or break;
    }
    int whiles = 0;
    do
    {
      whiles++;
    }while(whiles != 0 || whiles != 1); // || is or, && is and, and '!' is often used to signify "not" ; example: if (!(a == 1))
    String abc = "123";
    int abc = Integer.parseInt(abc); // yields 123 as a number
    	String.valueOf();
  }
}